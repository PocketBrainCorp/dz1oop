#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
using namespace std;

int len_digit(int d) {
    int len = 0;
    while(d > 0) {
        len++;
        d /= 10;
    }
    return len;
}

class Quadrat {
protected:
    int**_tab;
    int _degree;
    int _row;
    int _column;
public:
    Quadrat(int);
    ~Quadrat();
};

Quadrat::Quadrat(int d) : _degree(d) {
    _tab = new int*[_degree];
    for(_row = 0; _row < _degree; _row++) {
        _tab[_row] = new int[_degree];
        for(_column = 0; _column < _degree; _column++)
            _tab[_row][_column] = 0;
    }
}

Quadrat::~Quadrat() {
    for(_row = 0; _row < _degree; _row++)
        delete[] _tab[_row];
    delete[] _tab;
}

class Magic : public Quadrat {
    int check_border(int);
public:
    Magic(int);
    ~Magic();
    void print();
};

Magic::Magic(int d) : Quadrat(d) {
    int digit = 1;
    _row = 0;
    _column = 0;
    _tab[_row][_column] = digit++;
    while(digit <= _degree * _degree) {
        _row = check_border(_row + 2);
        _column = check_border(_column + 2);
        while(_tab[_row][_column] != 0) {
            _row = check_border(_row + 3);
            _column = check_border(_column + 1);
        }
        _tab[_row][_column] = digit++;
    }
}

Magic::~Magic() {
}

int Magic::check_border(int n) {
    if(n > _degree - 1)
        return n - _degree;
    if(n < 0)
        return n + _degree;
    return n;
}

void Magic::print() {
    int len = len_digit(_degree * _degree);
    
    for(_row = 0; _row < _degree; _row++) {
        for(_column = 0; _column < _degree; _column++)
            printf(" %*d ", len, _tab[_row][_column]);
        putchar('\n');
    }
}

int main(int argc, char** argv) {
    if(argc != 2) {
        cout << argv[0] << "Error!" << endl;
        return -1;
    }
    
    int argv_1 = atoi(argv[1]);
    
    if( argv_1 % 2 == 0) {
        cout << argv[0] << "Need an odd argument" << endl;
        return -1;
    }
    
    Magic q(argv_1);
    q.print();
    
    return 0;
}

